
/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  LuPeng                                                               */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  interface of menu                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by LuPeng,2014/09/29
 *
 */

#ifndef _MENU_H_

#define _MENU_H_
#define SUCCESS 0
#define FAILURE 1

#include<stdio.h>
#include<stdlib.h>

/*
 * Init the Menu
 */
int InitMenu();

/*
 * Add Command
 */
int AddCmd(char *cmd, char *desc);

/*
 * Show all commands in Menu
 */
int ShowAllCmd();

/*
 * Start Menu
 */
int MenuBegin();

#endif /* _MENU_H_ */
