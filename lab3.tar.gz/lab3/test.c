
/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  LuPeng                                                               */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  test driver of menu                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by LuPeng,2014/09/22
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"menu.h"

#define DEBUG printf

int result[4] = {1,1,1,1,};
char * info[4] =
{
    "InitMenu",
    "AddCmd",
    "MenuBegin",
    "ShowAllCmd",
};

int main()
{
    int i;
    char * cmd;
    char * desc;

    int ret = InitMenu();
    if(ret == SUCCESS)
    {
        DEBUG("TC1 Success - %s\n", info[0]);
        result[0] = 0;
    }

    ret = AddCmd(cmd, desc);
    if(ret == SUCCESS)
    {
        DEBUG("TC2 Success - %s\n", info[1]);
        result[0] = 0;
    }

    ret = MenuBegin();
    if(ret == SUCCESS)
    {
        DEBUG("TC3 Success - %s\n", info[2]);
        result[0] = 0;
    }

    ret = ShowAllCmd();
    if(ret == SUCCESS)
    {
        DEBUG("TC4 Success - %s\n", info[3]);
        result[0] = 0;
    }
}

