
/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  LuPeng                                                               */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/22                                                           */
/*  DESCRIPTION           :  menu program                                                         */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by LuPeng ,2014/09/22
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"menu.h"

#define SUCCESS 0
#define FAILURE 1

/*
 * Data Structure
 */
typedef struct DataNode
{
    char * cmd;
    char * desc;
    int (* handler)();
}tDataNode;

/*
 * Init the Menu
 */
int InitMenu()
{
    return SUCCESS;
}


/*
 * Add Commands
 */
int AddCmd(char *cmd, char *desc)
{
    if(cmd != NULL && desc != NULL)
    {
	return SUCCESS;
    }
}

/*
 * Show all Commands 
 */
int ShowAllCmd()
{
    return SUCCESS;
}

/*
 *  Menu Begin
 */
int MenuBegin()
{
    return SUCCESS;
}

